﻿using System;
using DitaParser;

namespace TestDitaParser
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter simple XML. When finished, type END");
            string input = Console.ReadLine();

            while(input !="END")
            {
                SimpleXMLReader xmlReader = new SimpleXMLReader(input);
                if(xmlReader.Validate(input))
                {
                    Console.WriteLine("Correct simple XML");
                    Console.WriteLine("The simple XML is as follows:");
                    foreach (SimpleXMLObject so in input)
                    {
                        
                        Console.WriteLine("Tag Name: " + so.TagName);
                        Console.WriteLine("Text: " + so.Text);
                    }

                    
                }
                else
                {
                    Console.WriteLine("Incorrect simple XML");
                }
                input = Console.ReadLine();
            }
            Console.WriteLine("Press any key to exit");
            Console.ReadLine();
            Environment.Exit(0);
        }
    }
}
