﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace DitaParser
{
    public class SimpleXMLReader

    {
        

        public SimpleXMLReader() { }
        public SimpleXMLReader(string simplexmltext){}

        public List<string> ExtractXML (string text)
        {
            string[] firstSplit = text.Split('<');
            List<string> outText = new List<string>();
            foreach(string splitText in firstSplit)
            {
                string[] secondsplit = splitText.Split('>');
                foreach(string split2 in secondsplit)
                {
                    outText.Add(splitText);
                }
            }
            string tagname = outText.ElementAt(0);
            SimpleXMLObject so = new SimpleXMLObject(tagname, text);
            so.TagName = outText.ElementAt(0);
            so.Text = outText.ElementAt(1);
            

            return outText;
        }

        public bool Validate (string text)
        { 
            Regex valid = new Regex(@"<([a-zA-Z]*)>\b[^>]*[^<]*.*?</\1>");
            
            if (valid.IsMatch(text))
            {
               return true;
            }
            else
                return false;
            
            
            
           
        }
        
    }
}
