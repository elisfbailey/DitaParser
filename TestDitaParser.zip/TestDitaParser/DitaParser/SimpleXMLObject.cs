﻿using System;
namespace DitaParser
{
    public class SimpleXMLObject
    {
        public string TagName { get; set; }
        public string Text { get; set; }

        public SimpleXMLObject() {}
        public SimpleXMLObject(string tagname, string text)
        {
            this.TagName = tagname;
            this.Text = text;
        }
       
    }
}
