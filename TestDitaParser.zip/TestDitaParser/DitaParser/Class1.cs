﻿using System;

namespace DitaParser
{
    public class Class1
    {
    }
}
